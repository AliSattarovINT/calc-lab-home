import pathlib, subprocess, tempfile, sys, time, random

binary = str(pathlib.Path(sys.argv[1]).resolve())
count = 0
with tempfile.TemporaryDirectory(prefix='calc-extra-') as td:
    root = pathlib.Path(td)
    source = root / 'case.txt'
    out = root / 'out'
    def check(text, expected):
        global count
        source.write_bytes(text.encode())
        run = subprocess.run([binary, '-o', str(out), str(source)], capture_output=True, timeout=60)
        assert run.returncode == 0, (run.returncode, run.stderr.decode())
        assert not run.stderr, run.stderr.decode()
        files = list(out.glob('*.txt'))
        assert len(files) == 1
        got = files[0].read_text()
        assert got == expected, (text[:100], expected[:100], got[:100])
        count += 1
    examples = [
        ('', ''), (' \t\n# comment\n\t', ''),
        ('2**3**2\n', '512\n'), ('20/3/2\n', '3\n'),
        ('(0-7)/2\n', '-3\n'), ('0**0\n', '1\n'),
        ('1.5e3\n', 'ERROR:4\n'), ('5.\n', 'ERROR:2\n'),
        ('.5\n', 'ERROR:1\n'), ('2 * -3\n', 'ERROR:5\n'),
        ('1+2\n3+', 'ERROR:7\n'), ('1+2\n3+\n', 'ERROR:7\n'),
        ('#abc\n\n2/0', 'ERROR:9\n'), ('10/(3-3)\n', 'ERROR:4\n'),
        ('2**(1-2)\n', 'ERROR:4\n'), ('(0-8)**0.5\n', 'ERROR:6\n'),
        ('10.0**400\n', 'ERROR:5\n'), ('1.5/0.0\n', 'ERROR:5\n'),
        ('1.25*4\n0.1+0.2\n', '5\n0.3\n'),
        ('1/0 + &\n', 'ERROR:3\n'), ('1/(0 &)\n', 'ERROR:6\n'),
        ('9223372036854775807**1\n', '9223372036854775807\n'),
        ('0.5**(0-1)\n', '2\n'), ('1\x00+2\n', 'ERROR:2\n'),
    ]
    for text, expected in examples: check(text, expected)
    check('('*1000+'1'+')'*1000+'\n', '1\n')
    check('1**'*100000+'1\n', '1\n')
    check('1+'*1000000+'1\n', '1000001\n')
    check('1.25+2.75\n'*500000, '4\n'*500000)
    check('2+2\n'*300000+'3+\n', 'ERROR:1200003\n')
    # An independently evaluated generated tree checks precedence and integer
    # truncation; values are bounded to avoid the excluded overflow cases.
    random.seed(251)
    def tree(depth):
        if depth == 0 or random.random() < .3:
            n = random.randrange(10); return str(n), n
        a,x = tree(depth-1); b,y = tree(depth-1)
        op = random.choice(['+','-','*','/'])
        if op == '/' and y == 0: op = '+'
        if op == '+': value=x+y
        elif op == '-': value=x-y
        elif op == '*': value=x*y
        else: value=(abs(x)//abs(y))*(-1 if (x<0)!=(y<0) else 1)
        return '('+a+op+b+')', value
    generated = [tree(5) for _ in range(1000)]
    check('\n'.join(a for a,b in generated)+'\n', ''.join(str(b)+'\n' for a,b in generated))
    for args in [[], ['-x'], ['-d'], ['-o'], ['missing.txt'], ['-d','missing'],
                 ['-d', str(root), str(source)], ['-o',str(source),str(source)],
                 ['-o',str(root/'absent'/'out'),str(source)]]:
        run = subprocess.run([binary]+args, capture_output=True, timeout=10)
        assert run.returncode != 0 and run.stderr, args
        count += 1
print(f'Extra validation passed: {count} scenarios, including 1000 generated expressions, '
      '1000 nested parentheses, 100000 powers, a 2 MB line and a 5 MB file.')
